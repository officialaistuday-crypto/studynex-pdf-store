const adminState = {
  token: sessionStorage.getItem("studynexPdfAdminToken") || "",
  products: [],
  orders: [],
  categories: []
};

const loginPanel = document.querySelector("#loginPanel");
const loginForm = document.querySelector("#loginForm");
const adminEmail = document.querySelector("#adminEmail");
const adminPassword = document.querySelector("#adminPassword");
const adminApp = document.querySelector("#adminApp");
const productForm = document.querySelector("#productForm");
const formTitle = document.querySelector("#formTitle");
const resetForm = document.querySelector("#resetForm");
const formStatus = document.querySelector("#formStatus");
const adminProducts = document.querySelector("#adminProducts");
const ordersList = document.querySelector("#ordersList");
const categorySelect = document.querySelector("#category");

function rupee(value) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0
  }).format(Number(value || 0));
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

async function api(path, options = {}) {
  const headers = new Headers(options.headers || {});
  headers.set("x-admin-token", adminState.token);
  const response = await fetch(path, { ...options, headers });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(result.error || "Request failed");
  }
  return result;
}

function renderCategoryOptions() {
  categorySelect.innerHTML = adminState.categories
    .map((category) => `<option value="${escapeHtml(category)}">${escapeHtml(category)}</option>`)
    .join("");
}

function productDetails(product) {
  const pdfLabel = product.pdfFile ? `PDF: ${product.pdfFile.originalName || product.pdfFile.filename}` : "PDF not uploaded";
  const posterLabel = product.posterUrl ? "Poster uploaded" : "Auto poster";
  return `${escapeHtml(product.category)} | ${escapeHtml(product.exam)} | ${escapeHtml(pdfLabel)} | ${escapeHtml(posterLabel)}`;
}

function renderProducts() {
  if (!adminState.products.length) {
    adminProducts.innerHTML = `<p class="muted-text">Abhi koi PDF product nahi hai.</p>`;
    return;
  }

  adminProducts.innerHTML = adminState.products
    .map(
      (product) => `
        <article class="admin-item">
          <div class="admin-item-header">
            <div>
              <h3>${escapeHtml(product.title)}</h3>
              <p class="muted-text">${productDetails(product)}</p>
            </div>
            <strong class="price">${rupee(product.price)}</strong>
          </div>
          <div class="admin-actions">
            <button class="button ghost small edit-product" data-id="${escapeHtml(product.id)}" type="button">Edit</button>
            <button class="button ghost small download-pdf" data-id="${escapeHtml(product.id)}" type="button" ${product.pdfFile ? "" : "disabled"}>PDF</button>
            <button class="button danger small delete-product" data-id="${escapeHtml(product.id)}" type="button">Delete</button>
          </div>
        </article>
      `
    )
    .join("");
}

function renderOrders() {
  if (!adminState.orders.length) {
    ordersList.innerHTML = `<p class="muted-text">Abhi koi buyer request nahi hai.</p>`;
    return;
  }

  ordersList.innerHTML = adminState.orders
    .map(
      (order) => `
        <article class="order-item">
          <div class="order-item-header">
            <div>
              <h3>${escapeHtml(order.name)} - ${escapeHtml(order.productTitle)}</h3>
              <p class="muted-text">${escapeHtml(order.phone)} ${order.email ? `| ${escapeHtml(order.email)}` : ""}</p>
              <p class="muted-text">${escapeHtml(order.message || "No message")}</p>
            </div>
            <span class="pill">${escapeHtml(order.status)}</span>
          </div>
          <div class="admin-actions">
            <button class="button ghost small order-status" data-id="${escapeHtml(order.id)}" data-status="Contacted" type="button">Contacted</button>
            <button class="button ghost small order-status" data-id="${escapeHtml(order.id)}" data-status="Closed" type="button">Closed</button>
          </div>
        </article>
      `
    )
    .join("");
}

async function loadAll() {
  const [categoryResult, productResult, orderResult] = await Promise.all([
    fetch("/api/categories").then((res) => res.json()),
    api("/api/products"),
    api("/api/admin/orders")
  ]);

  adminState.categories = categoryResult.categories || [];
  adminState.products = productResult.products || [];
  adminState.orders = orderResult.orders || [];
  renderCategoryOptions();
  renderProducts();
  renderOrders();
}

function showAdmin() {
  loginPanel.hidden = true;
  adminApp.hidden = false;
}

function resetProductForm() {
  productForm.reset();
  document.querySelector("#productId").value = "";
  formTitle.textContent = "Add PDF product";
  formStatus.textContent = "";
}

function fillProductForm(product) {
  document.querySelector("#productId").value = product.id;
  document.querySelector("#title").value = product.title || "";
  document.querySelector("#category").value = product.category || "";
  document.querySelector("#exam").value = product.exam || "";
  document.querySelector("#price").value = product.price || 0;
  document.querySelector("#description").value = product.description || "";
  document.querySelector("#tags").value = (product.tags || []).join(", ");
  document.querySelector("#pages").value = product.pages || "";
  document.querySelector("#featured").checked = Boolean(product.featured);
  formTitle.textContent = "Edit PDF product";
  formStatus.textContent = "Poster/PDF choose karenge to old file replace ho jayegi.";
  window.scrollTo({ top: 0, behavior: "smooth" });
}

async function downloadPdf(productId) {
  const response = await fetch(`/api/admin/products/${productId}/pdf`, {
    headers: { "x-admin-token": adminState.token }
  });
  if (!response.ok) {
    const result = await response.json().catch(() => ({}));
    throw new Error(result.error || "PDF download failed");
  }
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = "studynex-pdf.pdf";
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

loginForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const response = await fetch("/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: adminEmail.value,
        password: adminPassword.value
      })
    });
    const login = await response.json();
    if (!response.ok) throw new Error(login.error || "Login failed");
    adminState.token = login.token;
    await loadAll();
    sessionStorage.setItem("studynexPdfAdminToken", adminState.token);
    showAdmin();
  } catch (error) {
    adminPassword.setCustomValidity(error.message);
    adminPassword.reportValidity();
    adminPassword.setCustomValidity("");
  }
});

productForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  formStatus.textContent = "Saving...";
  const formData = new FormData(productForm);
  const productId = document.querySelector("#productId").value;
  const path = productId ? `/api/admin/products/${productId}` : "/api/admin/products";
  const method = productId ? "PUT" : "POST";

  try {
    await api(path, { method, body: formData });
    formStatus.textContent = "Saved.";
    resetProductForm();
    await loadAll();
  } catch (error) {
    formStatus.textContent = error.message;
  }
});

resetForm.addEventListener("click", resetProductForm);

adminProducts.addEventListener("click", async (event) => {
  const editButton = event.target.closest(".edit-product");
  const deleteButton = event.target.closest(".delete-product");
  const downloadButton = event.target.closest(".download-pdf");

  if (editButton) {
    const product = adminState.products.find((item) => item.id === editButton.dataset.id);
    if (product) fillProductForm(product);
  }

  if (deleteButton) {
    const product = adminState.products.find((item) => item.id === deleteButton.dataset.id);
    if (!product || !confirm(`${product.title} delete karna hai?`)) return;
    await api(`/api/admin/products/${product.id}`, { method: "DELETE" });
    await loadAll();
  }

  if (downloadButton) {
    try {
      await downloadPdf(downloadButton.dataset.id);
    } catch (error) {
      alert(error.message);
    }
  }
});

ordersList.addEventListener("click", async (event) => {
  const button = event.target.closest(".order-status");
  if (!button) return;
  await api(`/api/admin/orders/${button.dataset.id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status: button.dataset.status })
  });
  await loadAll();
});

if (adminState.token) {
  loadAll()
    .then(showAdmin)
    .catch(() => sessionStorage.removeItem("studynexPdfAdminToken"));
}
